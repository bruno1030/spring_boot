package br.com.fiap.exercicio.repository;

import br.com.fiap.exercicio.model.Prioridade;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface PrioridadeRepository extends JpaRepository<Prioridade, Integer> {

    List<Prioridade> findByNivel(int nivel);

}
