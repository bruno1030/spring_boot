package br.com.fiap.exercicio.controller;

import br.com.fiap.exercicio.model.Prioridade;
import br.com.fiap.exercicio.repository.PrioridadeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.validation.Valid;

@Controller
@RequestMapping("prioridade")
public class PrioridadeController {

    @Autowired
    private PrioridadeRepository prioridadeRepository;

    @GetMapping("alterar/{id}")
    public String alterar(@PathVariable("id") int codigo, Model model){
        model.addAttribute("prioridade", prioridadeRepository.findById(codigo));
        return "prioridade/form";
    }

    @GetMapping("cadastrar")
    public String cadastrar(Prioridade prioridade){
        return "prioridade/form";
    }

    @PostMapping("remover")
    public String remover(int codigo, RedirectAttributes redirect){
        prioridadeRepository.deleteById(codigo);
        redirect.addFlashAttribute("msg", "Removido!");
        return "redirect:/prioridade/listar";
    }

    @GetMapping("buscar")
    public String buscar(int termoBusca, Model model){
        model.addAttribute("lista", prioridadeRepository.findByNivel(termoBusca));
        return "prioridade/lista";
    }

    @PostMapping("salvar")
    public String cadastrar(@Valid Prioridade prioridade, BindingResult result, RedirectAttributes redirect){
        if (!result.hasErrors()){
            boolean cadastro =  prioridade.getCodigo() == 0;
            prioridadeRepository.save(prioridade);
            if (cadastro){
                redirect.addFlashAttribute("msg", "Cadastrado!");
                return "redirect:/prioridade/cadastrar";
            }
            redirect.addFlashAttribute("msg", "Alterado!");
            return "redirect:/prioridade/listar";
        }
        return "prioridade/form";
    }

    @GetMapping("listar")
    public String lista(Model model){
        model.addAttribute("lista", prioridadeRepository.findAll());
        return "prioridade/lista";
    }

}
