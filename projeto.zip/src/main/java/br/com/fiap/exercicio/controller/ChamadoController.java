package br.com.fiap.exercicio.controller;

import br.com.fiap.exercicio.model.Chamado;
import br.com.fiap.exercicio.repository.ChamadoRepository;
import br.com.fiap.exercicio.repository.PrioridadeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.validation.Valid;

@Controller
@RequestMapping("chamado")
public class ChamadoController {

    @Autowired
    private ChamadoRepository chamadoRepository;

    @Autowired
    private PrioridadeRepository prioridadeRepository;

    @GetMapping("cadastrar")
    public String cadastrar(Chamado chamado, Model model){
        model.addAttribute("prioridades", prioridadeRepository.findAll());
        return "chamado/form";
    }

    @PostMapping("salvar")
    public String cadastrar(@Valid Chamado chamado, BindingResult result, RedirectAttributes redirect){
        if (!result.hasErrors()){
            chamadoRepository.save(chamado);
            redirect.addFlashAttribute("msg", "Cadastrado!");
            return "redirect:/chamado/listar";
        }
        return "chamado/form";
    }

    @GetMapping("listar")
    public String lista(Model model){
        model.addAttribute("prioridades", prioridadeRepository.findAll());
        model.addAttribute("lista", chamadoRepository.findAll());
        return "chamado/lista";
    }

    @GetMapping("buscar")
    public String buscar(int termoBusca, Model model){
        model.addAttribute("prioridades", prioridadeRepository.findAll());
        model.addAttribute("lista", chamadoRepository.findByPrioridade_Codigo(termoBusca));
        return "chamado/lista";
    }

    @PostMapping("finalizar")
    public String finalizar(int codigo, RedirectAttributes redirect){
        Chamado chamado = chamadoRepository.findById(codigo).get();
        chamado.setFinalizado(true);
        chamadoRepository.save(chamado);
        redirect.addFlashAttribute("msg", "Finalizado!");
        return "redirect:/chamado/listar";
    }
    @GetMapping("pesquisar")
    public String buscar(String termoPesquisa, Model model){
        model.addAttribute("prioridades", prioridadeRepository.findAll());
        model.addAttribute("lista", chamadoRepository.findByTituloContains(termoPesquisa));
        return "chamado/lista";
    }



}
